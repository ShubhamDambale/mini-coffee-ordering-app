// Add the coffee to local storage with key "coffee"
