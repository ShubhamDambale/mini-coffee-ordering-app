// On clicking remove button the item should be removed from DOM as well as localstorage.
